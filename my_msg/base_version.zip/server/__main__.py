import select
import threading
from socket import *
from pathlib import Path
import sys
import logging
from handlers import handle_request
from argparse import ArgumentParser
from core.meta import ServerVerifier

# путь к папке
BASE_DIR = Path(__file__).resolve(strict=True).parent.parent
sys.path.append(str(BASE_DIR))
import core.settings as settings
import core.utils as utils

# logging
handler = logging.FileHandler('server.log', encoding=settings.ENCODING)
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s', handlers=[handler, ])

# получение параметров
try:
    host = getattr(settings, 'HOST', '127.0.0.1')
    port = getattr(settings, 'PORT', 7777)
    coding = getattr(settings, 'ENCODING', 'ascii')
    buffersize = settings.BUFFERSIZE
    parser = ArgumentParser()
    parser.add_argument('-a', '--addr', type=str, help='Sets ip address', default=host)
    parser.add_argument('-p', '--port', type=int, help='Sets port', default=port)

    args = parser.parse_args()
    host = args.addr
    port = args.port

    # logging
    handler = logging.FileHandler('server.log', encoding=settings.ENCODING)

    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            handler,
        ]
    )
except IndexError:
    print('Settings error')
    sys.exit(1)


# def read_requests(r_client, clients):  # функция считывания и декодирования ответов от клиентов
#     responses = {}
#     for sock in r_client:
#         print(sock)
#         try:
#             data = utils.get_message(sock, buffersize, coding)  # сообщение от клиента
#             print(f'Cообщение от клиента: {data}')
#             responses[sock] = data
#         except:
#             clients.remove(sock)
#     return responses


def read_client_data(client, requests, buffersize):
    try:
        b_request = client.recv(buffersize)
    except ConnectionResetError:
        b_request = b''
    if b_request != b'':
        requests.append(b_request)


# def write_responses(requests, w_client, clients):  # функция формирования ответов клиенту
#     for sock in w_client:
#         if sock in requests:
#             try:
#                 print(f'Формирование ответа для: {sock}')
#                 logging.info(f'Формирование ответа для: {sock}')
#                 sock.send(utils.send_message(requests[sock], coding))
#                 sock.close()
#             except:
#                 sock.close()
#                 clients.remove(sock)


def write_client_data(client, response):
    client.send(response)


def main():
    s = socket(AF_INET, SOCK_STREAM)  # сокет будет сетевым и потоковым
    s.bind((host, port))  # привязка сокета к адресу
    s.listen(5)  # 5 запросов одновременно
    s.settimeout(0)
    connections = []  # список клиентов
    requests = []  # список запросов
    logging.info(f'Сервер начал с параметрами: {host}:{port}')
    print(f'Сервер начал с параметрами: {host}:{port}')

    while True:  # ожидание сообщения
        try:  # поиск новых соединений
            client, addr = s.accept()  # создание соединения
        except OSError as e:
            pass
        else:
            print(f'Соединение с: {addr}')
            logging.info(f'Client detected {addr}')
            connections.append(client)  # добавление нового клиента
        finally:
            r, w, e = [], [], []

            try:
                if connections != []:  # если в списке клиентов кто то есть
                    r, w, e = select.select(connections, connections, connections, 0)
            except Exception as e:
                pass

            # requests_list = read_requests(r, connections)  # считываем запросы клиентов

            for r_client in r:
                thread = threading.Thread(
                    target=read_client_data,
                    args=(r_client, requests, settings.BUFFERSIZE)
                )
                thread.start()

        try:
            # if connections:  # если есть запросы, формируем ответы
            #     b_request = connections
            #     print(f'запрос: {b_request}')
            #     if b_request != b'':  # если запрос не битовый
            #         b_response = handle_request(b_request)  # преобразовать запрос в битовый
            if requests:
                b_request = requests.pop()
                print(f'request: {b_request}')
                if b_request != b'':
                    b_response = handle_request(b_request)

                for w_client in w:
                    thread = threading.Thread(  # разделение по потокам
                        target=write_client_data,  # вызов функции отправки сообщения
                        args=(w_client, b_response)  # клиент и битовый ответ
                    )
                    thread.start()  # начать отправку

                # write_responses(requests_list, w, connections)

        except(ValueError):
            logging.info(f'Ошибка сообщения')
            print('Сообщение не корректно')
            client.close()


if __name__ == '__main__':
    main()
