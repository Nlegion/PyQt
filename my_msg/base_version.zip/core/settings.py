HOST = "127.0.0.1"
PORT = 7777
BUFFERSIZE = 1024
ENCODING = 'utf-8'

INSTALLED_MODULES = [
    'dates',
    'echo',
    'exit'
]
