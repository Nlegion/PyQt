from .controllers import (
    get_date_now
)

routes = [
    {'action': 'now', 'controller': get_date_now}
]
