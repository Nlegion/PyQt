from .controllers import (
    get_exit
)

routes = [
    {'action': 'exit', 'controller': get_exit}
]